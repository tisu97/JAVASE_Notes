package cn.itcast.day07.demo02;

public class Person {

    String name;

    public void showName() {
        System.out.println("我叫：" + name);
    }

}
