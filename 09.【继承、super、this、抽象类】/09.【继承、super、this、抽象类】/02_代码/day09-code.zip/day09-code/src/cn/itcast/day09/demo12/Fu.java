package cn.itcast.day09.demo12;

public abstract class Fu {

    public Fu() {
        System.out.println("抽象父类构造方法执行！");
    }

    public abstract void eat();

}
