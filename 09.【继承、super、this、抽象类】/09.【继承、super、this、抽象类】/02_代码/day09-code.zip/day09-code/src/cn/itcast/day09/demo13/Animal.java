package cn.itcast.day09.demo13;

// 最高的抽象父类
public abstract class Animal {

    public abstract void eat();

    public abstract void sleep();

}
