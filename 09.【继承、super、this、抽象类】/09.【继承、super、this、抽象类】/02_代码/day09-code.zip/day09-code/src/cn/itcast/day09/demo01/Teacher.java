package cn.itcast.day09.demo01;

// 定义了一个员工的子类：讲师
public class Teacher extends Employee {

}
