package cn.itcast.day09.demo05;

public class Zi extends Fu {

    @Override
    public String method() {
        return null;
    }

}
