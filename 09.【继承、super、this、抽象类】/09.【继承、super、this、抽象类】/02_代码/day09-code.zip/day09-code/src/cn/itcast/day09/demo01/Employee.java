package cn.itcast.day09.demo01;

// 定义一个父类：员工
public class Employee {

    public void method() {
        System.out.println("方法执行！");
    }

}
