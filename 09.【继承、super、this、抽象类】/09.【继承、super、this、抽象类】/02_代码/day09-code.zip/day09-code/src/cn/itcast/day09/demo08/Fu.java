package cn.itcast.day09.demo08;

public class Fu {

    int num = 10;

    public void method() {
        System.out.println("父类方法");
    }

}
