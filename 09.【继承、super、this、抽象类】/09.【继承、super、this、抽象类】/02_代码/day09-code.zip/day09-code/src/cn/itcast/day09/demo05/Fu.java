package cn.itcast.day09.demo05;

public class Fu {

    public String method() {
        return null;
    }

}
