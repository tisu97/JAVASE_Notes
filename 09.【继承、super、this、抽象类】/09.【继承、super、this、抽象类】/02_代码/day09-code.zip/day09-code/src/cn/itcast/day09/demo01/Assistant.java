package cn.itcast.day09.demo01;

// 定义了员工的另一个子类：助教
public class Assistant extends Employee {
}
