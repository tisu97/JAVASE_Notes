package cn.itcast.day09.demo09;

public class Fu {

    int num = 30;

}
