package cn.itcast.day09.demo03;

public class Fu {

    int num = 10;

}
