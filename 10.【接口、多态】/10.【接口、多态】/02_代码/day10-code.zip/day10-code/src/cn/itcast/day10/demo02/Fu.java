package cn.itcast.day10.demo02;

public class Fu {

    public void method() {
        System.out.println("父类方法");
    }

}
