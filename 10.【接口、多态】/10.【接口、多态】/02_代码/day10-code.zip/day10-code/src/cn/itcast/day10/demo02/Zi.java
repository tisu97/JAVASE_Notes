package cn.itcast.day10.demo02;

public class Zi extends Fu implements MyInterface {
}
