package cn.itcast.day10.demo07;

public interface USB {

    public abstract void open(); // 打开设备

    public abstract void close(); // 关闭设备

}
