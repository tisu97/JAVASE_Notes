package cn.itcast.day10.demo01;

public class MyInterfaceStaticImpl implements MyInterfaceStatic {
}
