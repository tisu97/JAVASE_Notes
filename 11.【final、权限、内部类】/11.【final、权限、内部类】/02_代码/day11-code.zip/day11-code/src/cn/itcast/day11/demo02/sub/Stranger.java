package cn.itcast.day11.demo02.sub;

import cn.itcast.day11.demo02.MyClass;

public class Stranger {

    public void methodStrange() {
        System.out.println(new MyClass().num);
    }

}
