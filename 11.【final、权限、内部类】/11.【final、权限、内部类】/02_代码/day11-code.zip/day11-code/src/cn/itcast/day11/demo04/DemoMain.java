package cn.itcast.day11.demo04;

public class DemoMain {

    public static void main(String[] args) {
        Outer obj = new Outer();
        obj.methodOuter();
    }

}
