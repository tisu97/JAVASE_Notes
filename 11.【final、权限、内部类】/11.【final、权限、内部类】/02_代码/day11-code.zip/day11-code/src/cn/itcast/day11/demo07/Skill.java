package cn.itcast.day11.demo07;

public interface Skill {

    void use(); // 释放技能的抽象方法

}
