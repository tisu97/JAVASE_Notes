package cn.itcast.day11.demo02.sub;

import cn.itcast.day11.demo02.MyClass;

public class MySon extends MyClass {


    public void methodSon() {
//        System.out.println(super.num);
    }

}
